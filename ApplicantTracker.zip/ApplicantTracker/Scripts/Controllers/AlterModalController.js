﻿//angular.module('sbAdminApp').controller('AlterModalController',
//    ['$scope', '$modalInstance', '$modalStack', 'param1', function ($scope, $modalInstance, $modalStack, param1) {


//        $scope.closeAll = function () {
//            $modalStack.dismissAll('cancel');
//        };

//        $scope.cancel = function () {
//            $modalInstance.dismiss('cancel');
//        };
//        $scope.ok = function () {
//            $modalInstance.close();
//        };
//    }]);