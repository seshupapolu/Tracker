﻿using ApplicantTracker.InfraStructure;
using ApplicantTracker.InfraStructure.Interfaces;
using ApplicantTracker.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Web.Http;

namespace ApplicantTracker.Controllers
{

    public class ApptrackController : BaseController
    {


        private readonly IBusinessLayer _businessLayer;

        public ApptrackController()
        {
            _businessLayer = new BusinessLayer();
        }

        public ApptrackController(IBusinessLayer businessLayer)
        {
            _businessLayer = businessLayer;
        }

        [HttpGet]
        [Route("api/Apptrack/testnormal")]
        public IEnumerable<Data.AppTrackEntities.candidate> GetAllCandidates()
        {


            return _businessLayer.GetAllCandidates();
        }
        
        [HttpGet]
        [Route("api/Apptrack/GetAllCandidatesAsync")]
        public IEnumerable<Data.AppTrackEntities.candidate> GetAllCandidatesAsync()
        {
            //******Web API with EF CRUD operations testing start***********
            Data.AppTrackEntities.user employee = new Data.AppTrackEntities.user()
            {
                FirstName = "Shekar async",
                LastName = "Gadamoni",
                UserId = 1243,
                Password = "test123",
                Mobile = "9703471377",
                MaritalStatus = "M",
                IsActive = true,
                Gender = "M",
                Email = "test@gmail.com",
                Details = "tst",
                DOB = null,
                Address = "Hyderabad"

            };
            //test create
            _businessLayer.AddEmployeeAsync(employee);
            //test update
            _businessLayer.UpdateEmploeeAsync(employee);
            //test get
            //test remove
            //_businessLayer.RemoveEmployeeAsync(employee);
            //test get
            var a = _businessLayer.GetAllEmployeesAsync();
            //******Web API with EF CRUD operations testing end***********


            return _businessLayer.GetAllCandidates();
        }

        // GET: api/Apptrack/5
        [HttpGet]
        [Route("api/Apptrack/Candidate")]
        public Data.AppTrackEntities.candidate Get(string mail)
        {
            return _businessLayer.GetCandidateByMail(mail);
        }
        
        [HttpGet]
        [Route("api/Apptrack/CandidateById")]
        public CandidateViewModel GetCandidate(int id)
        {
            var candidate = _businessLayer.GetCandidateById(id);
            return new CandidateViewModel(candidate);

        }

        [HttpPost]
        [Route("api/Apptrack/CandidateProfiles")]
        public List<ProfileViewModel> GetCandidateProfiles()
        {
            List<ProfileViewModel> profiles = new List<ProfileViewModel>();
            for (int i = 0; i < 100; i++)
            {
                profiles.Add(new ProfileViewModel
                {
                    CandidateId = 1,
                    ProfileId = i + 1,
                    CompanyName = "CompanyName" + i,
                    CurrentStatus = "InProgress"    

                });
            }
            // System.Threading.Thread.Sleep(5000);
            //var result = await LongRunningOperation();
            //await Task.Run(() =>
            //{
            //    LongRunningOperation();
            //});
            //var candidate = _businessLayer.GetCandidateById(id);
            //return new CandidateViewModel(candidate);

            return profiles;

        }
        
        [HttpGet]
        [Route("api/Apptrack/SearchableItems")]
        public SearchItemViewModel GetSearchableItems()
        {
            return GetItems();


        }

        private SearchItemViewModel GetItems()
        {
            SearchItemViewModel model = new SearchItemViewModel();

            model.Companies.AddRange(GetCompanyList());
            model.CreatedBy.AddRange(GetCreatedByList());
            model.Experiences.AddRange(GetExperienceList());
            model.Locations.AddRange(GetLocationList());
            model.Roles.AddRange(GetRoleList());
            model.Salaries.AddRange(GetSalaryList());
            model.Statuses.AddRange(GetStatusList());

            return model;

        }

        private IEnumerable<ItemViewModel> GetStatusList()
        {
            List<ItemViewModel> list = new List<ItemViewModel>();
            list.Add(new ItemViewModel
            {
                Code = 1,
                Name = "Assigned",
                Show = true
            });
            list.Add(new ItemViewModel
            {
                Code = 2,
                Name = "InReview",
                Show = true
            });

            list.Add(new ItemViewModel
            {
                Code = 3,
                Name = "InProgress"
            });

            list.Add(new ItemViewModel
            {
                Code = 4,
                Name = "Interview Scheduled"
            });

            list.Add(new ItemViewModel
            {
                Code = 5,
                Name = "Offer Accepted"
            });

            list.Add(new ItemViewModel
            {
                Code = 5,
                Name = "Offer Accepted"
            });
            list.Add(new ItemViewModel
            {
                Code = 5,
                Name = "Offer Accepted"
            });
            list.Add(new ItemViewModel
            {
                Code = 5,
                Name = "Offer Accepted"
            });
            list.Add(new ItemViewModel
            {
                Code = 5,
                Name = "Offer Accepted"
            });
            list.Add(new ItemViewModel
            {
                Code = 5,
                Name = "Offer Accepted"
            });
            list.Add(new ItemViewModel
            {
                Code = 5,
                Name = "Offer Accepted"
            });
            list.Add(new ItemViewModel
            {
                Code = 5,
                Name = "Offer Accepted"
            });
            list.Add(new ItemViewModel
            {
                Code = 5,
                Name = "Offer Accepted"
            });
            list.Add(new ItemViewModel
            {
                Code = 5,
                Name = "Offer Accepted"
            });
            list.Add(new ItemViewModel
            {
                Code = 5,
                Name = "Offer Accepted"
            });
            list.Add(new ItemViewModel
            {
                Code = 5,
                Name = "Offer Accepted"
            });
            list.Add(new ItemViewModel
            {
                Code = 5,
                Name = "Offer Accepted"
            });
            list.Add(new ItemViewModel
            {
                Code = 5,
                Name = "Offer Accepted"
            });
            list.Add(new ItemViewModel
            {
                Code = 5,
                Name = "Offer Accepted"
            });
            list.Add(new ItemViewModel
            {
                Code = 5,
                Name = "Offer Accepted"
            });
            list.Add(new ItemViewModel
            {
                Code = 5,
                Name = "Offer Accepted"
            });
            list.Add(new ItemViewModel
            {
                Code = 5,
                Name = "Offer Accepted"
            });
            list.Add(new ItemViewModel
            {
                Code = 5,
                Name = "Offer Accepted"
            });

            return list;
        }

        private IEnumerable<ItemViewModel> GetSalaryList()
        {
            List<ItemViewModel> list = new List<ItemViewModel>();
            list.Add(new ItemViewModel
            {
                Code = 1,
                Name = "0-1,00,000",
                Show = true
            });
            list.Add(new ItemViewModel
            {
                Code = 2,
                Name = "1,00,000-2,00,000",
                Show = true
            });

            list.Add(new ItemViewModel
            {
                Code = 3,
                Name = "2,00,000-5,00,000"
            });

            list.Add(new ItemViewModel
            {
                Code = 4,
                Name = "5,00,000-8,00,000"
            });

            list.Add(new ItemViewModel
            {
                Code = 5,
                Name = "8,00,000-10,00,000"
            });

            return list;
        }

        private IEnumerable<ItemViewModel> GetRoleList()
        {
            List<ItemViewModel> list = new List<ItemViewModel>();
            list.Add(new ItemViewModel
            {
                Code = 1,
                Name = "Programmer",
                Show = true
            });
            list.Add(new ItemViewModel
            {
                Code = 2,
                Name = "SE",
                Show = true
            });

            list.Add(new ItemViewModel
            {
                Code = 3,
                Name = "ITA"
            });

            list.Add(new ItemViewModel
            {
                Code = 4,
                Name = "Manager"
            });

            list.Add(new ItemViewModel
            {
                Code = 5,
                Name = "SM"
            });

            return list;
        }

        private IEnumerable<ItemViewModel> GetLocationList()
        {
            List<ItemViewModel> list = new List<ItemViewModel>();
            list.Add(new ItemViewModel
            {
                Code = 1,
                Name = "Hyderabad",
                Show = true
            });
            list.Add(new ItemViewModel
            {
                Code = 2,
                Name = "Amaravati",
                Show = true
            });

            list.Add(new ItemViewModel
            {
                Code = 3,
                Name = "Tenali"
            });

            list.Add(new ItemViewModel
            {
                Code = 4,
                Name = "Guntur"
            });

            list.Add(new ItemViewModel
            {
                Code = 5,
                Name = "Vizag"
            });

            return list;
        }

        private IEnumerable<ItemViewModel> GetExperienceList()
        {
            List<ItemViewModel> list = new List<ItemViewModel>();
            list.Add(new ItemViewModel
            {
                Code = 1,
                Name = "0-2",
                Show = true
            });
            list.Add(new ItemViewModel
            {
                Code = 2,
                Name = "2-5",
                Show = true
            });

            list.Add(new ItemViewModel
            {
                Code = 3,
                Name = "5-8"
            });

            list.Add(new ItemViewModel
            {
                Code = 4,
                Name = "8-10"
            });

            list.Add(new ItemViewModel
            {
                Code = 5,
                Name = "> 10"
            });

            return list;
        }

        private IEnumerable<ItemViewModel> GetCreatedByList()
        {
            List<ItemViewModel> list = new List<ItemViewModel>();
            list.Add(new ItemViewModel
            {
                Code = 1,
                Name = "Shekar",
                Show = true
            });
            list.Add(new ItemViewModel
            {
                Code = 2,
                Name = "Nitya",
                Show = true
            });

            list.Add(new ItemViewModel
            {
                Code = 3,
                Name = "Pavan"
            });

            list.Add(new ItemViewModel
            {
                Code = 4,
                Name = "Thiru"
            });

            return list;
        }

        private IEnumerable<ItemViewModel> GetCompanyList()
        {
            List<ItemViewModel> companies = new List<ItemViewModel>();
            companies.Add(new ItemViewModel
            {
                Code = 1,
                Name = "TATA Consultancy Services",
                Show = true
            });
            companies.Add(new ItemViewModel
            {
                Code = 2,
                Name = "Cognizant",
                Show = true
            });

            companies.Add(new ItemViewModel
            {
                Code = 3,
                Name = "Microsoft"
            });

            companies.Add(new ItemViewModel
            {
                Code = 4,
                Name = "IBM"
            });

            return companies;
        }

        [HttpPost]
        [Route("api/Apptrack/SearchCandidate")]
        public IList<CandidateViewModel> SearchCandidate(SearchInputViewModel searchInputViewModel)
        {



            //System.Threading.Thread.Sleep(3000);
            //var result = await LongRunningOperation();
            //string searchText;
            //string canStatus;
            //bool isMostRecent;
            //bool isEmail;
            //bool isMobile;
            //bool isKeyword;
            //string company;
            //string byRole;
            //string createdBy;
            //string location;
            //string salary;

            //ConvertModelToSearchRequest(searchInputViewModel, out  searchText, out  canStatus, out createdBy, out location, out salary, out  isMostRecent, out  isEmail, out  isMobile, out  isKeyword, out  company, out  byRole);


            // _businessLayer.SearchApplicantAsync(searchText, canStatus,createdBy,location,salary, isMostRecent, isEmail, isMobile, isKeyword, company, byRole);


            //await Task.Run(() =>
            //{
            //    LongRunningOperation();
            //});
            //var candidate = _businessLayer.GetCandidateById(id);
            //return new CandidateViewModel(candidate);

            List<CandidateViewModel> model = new List<CandidateViewModel>();

            for (int i = 0; i < 10; i++)
            {
                model.Add(new CandidateViewModel
                {
                    CandidateId = i,
                    FirstName = "FirstName" + i,
                    LastName = "LastName" + i,
                    MiddleName = "MiddleName" + i,
                    MobileNumber = "0000000000000000" + i,
                    CandidateStatus = "Pending"

                });
            }
            return model;

        }

        //private void ConvertModelToSearchRequest(SearchInputViewModel searchInput, out string searchText, out string canStatus,out string createdBy,out string location,out string salary,out bool isMostRecent, out bool isEmail, out bool isMobile, out bool isKeyword, out string company, out string byRole)
        //{
        //    searchText = searchInput.Keyword;
        //    canStatus = searchInput.Status;
        //    isMostRecent = searchInput.IsRecent;
        //    isEmail = searchInput.IsEmailAddress;
        //    isMobile = searchInput.IsPhoneAddress;
        //    isKeyword = searchInput.IsKeyword;
        //    company = searchInput.Company;
        //    byRole = searchInput.Role;
        //    createdBy=string.Empty;
        //    location=string.Empty;
        //    salary = string.Empty;




        //}

        private static async Task<bool> LongRunningOperation()
        {
            int counter;

            for (counter = 0; counter < 500; counter++)
            {
                Console.WriteLine(counter);
            }

            return true;
        }

        //private Func<bool> ReturnBool()
        //{
        //    return bool

        //}

        [HttpPost]
        [Route("api/Apptrack/CreateCandidate")]
        public bool Create([FromBody]CandidateViewModel model)
        {
            Data.AppTrackEntities.candidate candidate = new Data.AppTrackEntities.candidate
            {
                CreateDate = DateTime.Now,
                CurrentCTC = model.CurrentCTC,
                CurrentDesignation = model.CurrentDesignation,
                CurrentLocation = model.CurrentLocation,
                DOB = model.DateOfBirth,
                Email = model.Email,
                FirstName = model.FirstName,
                LastName = model.LastName,
                MiddleName = model.MiddleName,
                MobileNumber = model.MobileNumber,
                HomeTown = model.HomeTown,
                Source = model.Source,
                SecondaryEmail = model.SecondaryEmail,
                AlternateNumber = model.AlternateNumber
            };
            try
            {
                // _businessLayer.AddCandidate(candidate);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        [HttpPost]
        [Route("api/Apptrack/UpdateCandidate")]
        public bool Update([FromBody]CandidateViewModel model)
        {
            Data.AppTrackEntities.candidate candidate = new Data.AppTrackEntities.candidate
            {
                CandidateId = model.CandidateId,
                CreateDate = DateTime.Now,
                CurrentCTC = model.CurrentCTC,
                CurrentDesignation = model.CurrentDesignation,
                CurrentLocation = model.CurrentLocation,
                DOB = model.DateOfBirth,
                Email = model.Email,
                FirstName = model.FirstName,
                LastName = model.LastName,
                MiddleName = model.MiddleName,
                MobileNumber = model.MobileNumber,
                HomeTown = model.HomeTown,
                Source = model.Source,
                SecondaryEmail = model.SecondaryEmail,
                AlternateNumber = model.AlternateNumber
            };
            try
            {
                // _businessLayer.AddCandidate(candidate);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        // GET: api/Apptrack/5
        public string Get(int id)
        {
            return "value";
        }

        // POST: api/Apptrack
        public void Post([FromBody]string value)
        {
        }

        // PUT: api/Apptrack/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE: api/Apptrack/5
        public void Delete(int id)
        {
        }
    }
}
