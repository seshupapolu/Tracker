﻿(function (angular) {
    angular.module('sbAdminApp').controller('adminStatusController',
        ['$scope', '$modal', 'userService', function ($scope, $modal, userService) {

            $scope.items = {};

            $scope.statusCreate = {};
            $scope.statusCreate.CanStatusId = '';
            $scope.statusCreate.Name = '';
            $scope.statusCreate.Description = '';
            $scope.statusCreate.IsActive = '';           

            userService.getAllIndustry()           
                       .success(function (data) {
                           debugger;
                           //alert(data);
                           $scope.items = data;
                           // $scope.isLoading = false;                            

                       })
                       .error(function (data) {
                           debugger;
                           //$scope.isLoading = false;
                           console.log('Error: ', data)
                       });

            $scope.open = function (size) {
                debugger;
                var modalInstance = $modal.open({
                    size: '100px',
                    animation: false,
                    backdrop: 'static',
                    templateUrl: '/Templates/Admin/admin-create-list.html',
                    controller: 'statusCreateCtrl',
                    scope: $scope,
                    windowClass: 'large-Modal',
                    resolve: {
                        statusCreate: function () {
                            return $scope.statusCreate;
                        }
                    }
                });
                modalInstance.result.then(function (response) {
                    debugger;
                }, function () {
                    $log.info('Modal dismissed at: ' + new Date());
                });
            };


            $scope.createEdit = function (id, flag) {
                            
                userService.getAllIndustry()
                      .success(function (data) {

                          debugger;
                          $scope.items = data;
                          $scope.statusEdit = {};
                          $scope.statusEdit.CanStatusId = id + 1;;

                          angular.forEach($scope.items, function (value, key) {
                              debugger;

                              if (value.CanStatusId == $scope.statusEdit.CanStatusId) {

                                  $scope.statusEdit.Name = value.Name;
                                  $scope.statusEdit.Description = value.Description;
                                  $scope.statusEdit.IsActive = value.IsActive;
                               }

                          });

                           debugger;
                          var modalInstance = $modal.open({
                              size: '500px',
                              animation: false,
                              backdrop: 'static',
                              templateUrl: '/Templates/Admin/admin-edit-list.html',
                              controller: 'adminEditCtrl',
                              scope: $scope,
                              windowClass: 'large-Modal',
                              resolve: {
                                  adminEdit: function () {
                                      return $scope.adminEdit;
                                  }
                              }
                          });
                          modalInstance.result.then(function (response) {
                              debugger;
                          }, function () {
                              $log.info('Modal dismissed at: ' + new Date());
                          });


                      })
                      .error(function (data) {
                          debugger;
                          //$scope.isLoading = false;
                          console.log('Error: ', data)
                      });


            };

            $scope.deleteItem = function (industry, flag) {
                debugger;

                if (!flag) {

                    industry.IsActive = false;
                    userService.disableIndustry(industry);
                }

                $modalInstance.dismiss('cancel');
            };

        }]);

    angular.module('sbAdminApp').controller('adminEditCtrl',
 ['$scope', '$modalInstance', 'userService', function ($scope, $modalInstance, userService) {

     $scope.Update = function () {
         debugger;
         var model = $scope.statusEdit;
         userService.UpdateIndustry(model);

         userService.getAllIndustry()
                      .success(function (data) {
                          debugger;
                          //alert(data);
                          $scope.items = data;
                          // $scope.isLoading = false;                            

                      })
                      .error(function (data) {
                          debugger;
                          //$scope.isLoading = false;
                          console.log('Error: ', data)
                      });


         $modalInstance.dismiss('cancel');
     };

     $scope.ok = function () {
         $modalInstance.close();
     };

     $scope.cancel = function () {
         $modalInstance.dismiss('cancel');
     };
 }]);



    angular.module('sbAdminApp').controller('statusCreateCtrl',
['$scope', '$modalInstance', 'userService', function ($scope, $modalInstance, userService) {

    $scope.createStatus = function () {
        debugger;
        var model = $scope.statusCreate;
        userService.createIndustry(model);
        $modalInstance.dismiss('cancel');
    };

    $scope.ok = function () {
        $modalInstance.close();
    };

    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
}]);


})
(angular);