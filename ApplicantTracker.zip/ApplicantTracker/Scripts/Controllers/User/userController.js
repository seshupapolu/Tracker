﻿(function (angular) {
    angular.module('sbAdminApp').controller('userController',
        ['$scope', '$modal', 'userService', function ($scope, $modal, userService) {
           
            $scope.items = {};

            $scope.user = {};
            $scope.user.UserId = '';
            $scope.user.FirstName = '';
            $scope.user.MiddleName = '';
            $scope.user.LastName = '';
            $scope.user.Password = '';
            $scope.user.Details = '';
            $scope.user.DateOfBirth = '';
            $scope.user.Address = '';        
            $scope.user.MaritalStatus = '';            
            $scope.user.Mobile = '';
            $scope.user.Gender = '';
            $scope.user.Email = '';
            $scope.user.Branch = '';
            $scope.Users = [];

            $scope.IsExpanded = false;
            $scope.IsInfoExpanded = true;

            $scope.Initialize = function () {
               // $scope.isLoading = true;
                userService.getAllUsers()
                        .success(function (data) {                            
                            //alert(data);
                            $scope.items = data;
                           // $scope.isLoading = false;                            
                            
                        })
                        .error(function (data) {
                            debugger;
                            //$scope.isLoading = false;
                            console.log('Error: ', data)
                        });
            };

            $scope.open = function (size) {
                debugger;
                var modalInstance = $modal.open({
                    size: '1000px',
                    animation: false,
                    backdrop: 'static',
                    templateUrl: '/Templates/User/CreateUser.html',
                    controller: 'createUserCtrl',
                    scope: $scope,
                    windowClass: 'large-Modal',
                    resolve: {
                        user: function () {
                            return $scope.user;
                        }
                    }
                });
                modalInstance.result.then(function (response) {
                    debugger;                   
                }, function () {
                    $log.info('Modal dismissed at: ' + new Date());
                });
            };
         

            $scope.Edit = function (id, flag) {

                userService.getAllUsers()
                   .success(function (data) {

                       debugger;
                       $scope.items = data;
                       $scope.user = {};
                       $scope.user.UserId = id + 1;;

                       angular.forEach($scope.items, function (value, key) {
                           debugger;

                           if (value.UserId == $scope.user.UserId) {

                               $scope.user.FirstName = value.FirstName;
                               $scope.user.MiddleName = value.MiddleName;
                               $scope.user.LastName = value.LastName;
                               $scope.user.Password = value.Password;
                               $scope.user.Details = value.Details;
                               $scope.user.DateOfBirth = value.DateOfBirth;
                               $scope.user.Address = value.Address;
                               $scope.user.MaritalStatus = value.MaritalStatus;
                               $scope.user.Mobile = value.Mobile;
                               $scope.user.Gender = value.Gender;
                               $scope.user.Email = value.Email;
                               $scope.user.Branch = value.Branch;
                               $scope.user.IsActive = value.IsActive;
                           }

                       });

                       debugger;
                       var modalInstance = $modal.open({
                           size: '500px',
                           animation: false,
                           backdrop: 'static',
                           templateUrl: '/Templates/User/EditUser.html',
                           controller: 'userEditCtrl',
                           scope: $scope,
                           windowClass: 'large-Modal',
                           resolve: {
                               user: function () {
                                   return $scope.user;
                               }
                           }
                       });
                       modalInstance.result.then(function (response) {
                           debugger;
                       }, function () {
                           $log.info('Modal dismissed at: ' + new Date());
                       });


                   })
                   .error(function (data) {
                       debugger;
                       //$scope.isLoading = false;
                       console.log('Error: ', data)
                   });


            };

            $scope.deleteUser = function (user, flag) {
                debugger;
                
                if (!flag) {

                    user.IsActive = false;
                    userService.disableUser(user);
                }
                
                $modalInstance.dismiss('cancel');
            };

            
        }]);


    angular.module('sbAdminApp').controller('createUserCtrl',
      ['$scope', '$modalInstance', 'userService', function ($scope, $modalInstance, userService) {

          $scope.SaveUser = function () {
              debugger;
              var model = $scope.user;
              userService.submitUser(model);
              $modalInstance.dismiss('cancel');
          };

          $scope.ok = function () {
              $modalInstance.close();
          };

          $scope.cancel = function () {
              $modalInstance.dismiss('cancel');
          };
      }]);


    //angular.module('sbAdminApp').controller('editModalCtrl',
    //  ['$scope', '$modalInstance', 'userService', function ($scope, $modalInstance, userService) {


    //      $scope.update = function () {
    //          debugger;
    //          var model = $scope.user;
    //          userService.updateUser(model);              
    //          //Write service call here...
    //          $modalInstance.close();
    //      };
                   
    //      $scope.cancel = function () {
    //          $modalInstance.dismiss('cancel');
    //      };
    //  }]);


    angular.module('sbAdminApp').controller('userEditCtrl',
['$scope', '$modalInstance', 'userService', function ($scope, $modalInstance, userService) {

    $scope.update = function () {
        debugger;
        var model = $scope.user;
        userService.updateUser(model);

        userService.getAllUsers()
                     .success(function (data) {
                         debugger;                        
                         $scope.items = data;                                     
                     })
                     .error(function (data) {
                         debugger;                      
                         console.log('Error: ', data)
                     });


        $modalInstance.dismiss('cancel');
    };

    $scope.ok = function () {
        $modalInstance.close();
    };

    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
}]);
})
(angular);