﻿(function (angular) {
   
    angular.module('sbAdminApp').controller('DashboardController',
       ['$scope', '$modal', 'DashboardService', function ($scope, $modal, DashboardService) {

           $scope.ActiveProfiles = 0;
           $scope.Customers = [2, 4, 5, 6, 2, 3, 4, 5];
           $scope.NewInterviews = 0;
           $scope.OfferReleases = 0;
           $scope.NewProfiles = 0;
           $scope.TotalEmployees = 0;
           $scope.MemberActivities = { TotalRecords: { count: 100, values: [1, 5, 7, 3, 5, 2], nodes: 6 }, NewRecords: { count: 100, values: [1, 5, 7, 3, 5, 2], nodes: 6 }, Members: [{ MemberName: 'Nithi', Assigned: 100, Processed: 100, InterviewSchudled: 0 }] }
           $scope.GetDashboardCount = function () {
               debugger;
               var value = null;
               DashboardService.GetDashboardCount(value)
                   .success(function (data) {
                       $scope.ActiveProfiles = data.ActiveProfiles;
                       $scope.NewInterviews = data.NewInterviews;
                       $scope.OfferReleases = data.OfferReleases;
                       $scope.NewProfiles = data.NewProfiles;
                       $scope.TotalEmployees = data.TotalEmployees;
                       $scope.MemberActivities = { TotalRecords: { count: 100, values: [1, 5, 7, 3, 5, 2], nodes: 6 }, NewRecords: { count: 100, values: [1, 5, 7, 3, 5, 2], nodes: 6 }, Members: [{ MemberName: 'Nithi', Assigned: 100, Processed: 100, InterviewSchudled: 0 }] }
                       $scope.IsLoading = false;
                   })

                   .error(function (data) {
                       $scope.IsLoading = false;
                   });
           };

           $scope.RefreshDashboard = function (value) {
              debugger;
               if(value == 'week')
               {
                   $scope.MemberActivities.TotalRecords = 200;
                   $scope.MemberActivities.NewRecords = 150;
                  $scope.MemberActivities.Members = [{ MemberName: 'Nithi', Assigned: 79, Processed: 30, InterviewSchudled: 0, Total: 109 }, { MemberName: 'Nithi', Assigned: 79, Processed: 30, InterviewSchudled: 0, Total: 109 }];
                                }
               if(value == 'today')
               {
                   $scope.MemberActivities.TotalRecords = 20;
                   $scope.MemberActivities.NewRecords = 15;
                   $scope.MemberActivitie.Members = [{ MemberName: 'Nithi', Assigned: 50, Processed: 10, InterviewSchudled: 0, Total: 60 }];
                   
               }
               if(value == 'month')
               {
                   $scope.MemberActivities.TotalRecords = 2000;
                   $scope.MemberActivities.NewRecords = 1500;
                   $scope.MemberActivities.Members = [{ MemberName: 'Nithi', Assigned: 100, Processed: 100, InterviewSchudled: 0, Total: 1000 }, { MemberName: 'Nithi', Assigned: 79, Processed: 30, InterviewSchudled: 0, Total: 109 }, { MemberName: 'Nithi', Assigned: 79, Processed: 30, InterviewSchudled: 0, Total: 109 }, { MemberName: 'Nithi', Assigned: 79, Processed: 30, InterviewSchudled: 0, Total: 109 }, { MemberName: 'Nithi', Assigned: 79, Processed: 30, InterviewSchudled: 0, Total: 109 }];
                  
               }
              
           };
       }]);
}(angular));
