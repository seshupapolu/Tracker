﻿(function (angular) {

    angular.module('sbAdminApp').controller('ProfileController', ['$scope', '$modalInstance', '$log', 'ProfileService', function ($scope, $modalInstance, $log, ProfileService) {

        debugger;
        $scope.Profile = {};
        $scope.Profile.ProfileId = '';
        $scope.Profile.CandidateId = '';
        $scope.Profile.CompanyName = '';
        $scope.Profile.CompanyDetails = '';
        $scope.Profile.DateOfInterview = '';
        $scope.Profile.CurrentStatus = '';
        $scope.Profile.HRCopy = '';
        $scope.Profile.AppliedPositionFor = '';
        $scope.Profile.Interviewer = '';
        $scope.Profile.InterviewerContact = '';
        $scope.Profile.CompanyContact = '';
        $scope.Profile.ReferenceType = '';
        $scope.Profile.RecruiterName = '';
        $scope.Profile.RecruiterContact = '';
        $scope.Profile.TeamLeadName = '';
        $scope.Profile.CreateDate = '';
        $scope.Profile.CreatedBy = '';
        $scope.Profile.ModifiedDate = '';
        $scope.Profile.ModifiedBy = '';

        $scope.Profile.Candidate = {};
        $scope.Profile.Candidate.CandidateId = '';
        $scope.Profile.Candidate.FirstName = '';
        $scope.Profile.Candidate.MiddleName = '';
        $scope.Profile.Candidate.LastName = '';
        $scope.Profile.Candidate.MobileNumber = '';
        $scope.Profile.Candidate.AlternateNumber = '';
        $scope.Profile.Candidate.Email = '';
        $scope.Profile.Candidate.SecondaryEmail = '';
        $scope.Profile.Candidate.DateOfBirth = '';
        $scope.Profile.Candidate.CurrentEmployer = '';
        $scope.Profile.Candidate.CurrentDesignation = '';
        $scope.Profile.Candidate.CurrentCTC = '';
        $scope.Profile.Candidate.CurrentLocation = '';
        $scope.Profile.Candidate.HomeTown = '';
        $scope.Profile.Candidate.Source = '';
        $scope.Profile.Candidate.Status = '';
        $scope.Profiles = [];

        $scope.IsExpanded = false;
        $scope.IsInfoExpanded = true;

        
        $scope.SearchProfile = function () {
            debugger;
            //ProfileService.SearchProfile(model);
            $scope.Profiles = ProfileService.SearchProfiles('pavan228@gmail.com');
        }

        $scope.SaveProfile = function (size) {
            debugger;
            
            var model = $scope.Profile;
            ProfileService.CreateProfile(model);
        };

        $scope.cancel = function () {
            $modalInstance.dismiss('cancel');
        };
    }]);

    angular.module('sbAdminApp').controller('createModalCtrl', ['$scope', '$modalInstance', 'ProfileService', function ($scope, $modalInstance, ProfileService) {
        $scope.SaveProfile = function () {
            debugger;
            var model = $scope.Profile;
            ProfileService.CreateProfile(model);
        };

        $scope.ok = function () {
            $modalInstance.close();
        };

        $scope.cancel = function () {
            $modalInstance.dismiss('cancel');
        };
    }]);
}(angular));