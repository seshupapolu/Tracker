﻿using ApplicantTracker.InfraStructure;
using ApplicantTracker.InfraStructure.Interfaces;
using ApplicantTracker.Models;
using System.Web.Http;
using System.Web.Routing;


namespace ApplicantTracker.Controllers
{
    public class DashboardController : BaseController
    {
        
        private readonly IBusinessLayer _businessLayer;

        public DashboardController()
        {
            _businessLayer = new BusinessLayer();
        }

        public DashboardController(IBusinessLayer businessLayer)
        {
            _businessLayer = businessLayer;
        }

        [HttpGet]
        [Route("api/Apptrack/GetDashboardCount")]
       public DashboardViewModel GetDashboardCount()
        {
           var totalEmployees= _businessLayer.GetAllEmployeesAsync();
            DashboardViewModel count = new DashboardViewModel();
            count.ActiveProfiles = 10;
            count.NewInterviews = 8;
            count.OfferReleases = 20;
            count.NewProfiles = 6;
            count.TotalEmployees = totalEmployees.Result.Count;
            return count;
        }
    }
}