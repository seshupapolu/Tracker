﻿(function (angular) {


    angular.module('sbAdminApp').controller('CandidateController',
       ['$scope', '$modal', '$log', '$timeout', 'CandidateService', function ($scope, $modal, $log, $timeout, CandidateService) {



           $scope.searchInputViewModel = {};

           $scope.searchInputViewModel.IsRecent = false;
           $scope.searchInputViewModel.IsEmailAddress = false;
           $scope.searchInputViewModel.IsPhoneAddress = false;
           $scope.searchInputViewModel.IsKeyword = false;
           $scope.searchInputViewModel.Keyword = '';
           $scope.searchInputViewModel.Status = '';
           $scope.searchInputViewModel.Company = '';
           $scope.searchInputViewModel.Role = '';

           $scope.Message = '';


           $scope.Size = 0;
           $scope.Candidate = {};
           $scope.Candidate.CandidateId = '';
           $scope.Candidate.FirstName = '';
           $scope.Candidate.MiddleName = '';
           $scope.Candidate.LastName = '';
           $scope.Candidate.MobileNumber = '';
           $scope.Candidate.AlternateNumber = '';
           $scope.Candidate.Email = '';
           $scope.Candidate.SecondaryEmail = '';
           $scope.Candidate.DateOfBirth = '';
           $scope.Candidate.CurrentEmployer = '';
           $scope.Candidate.CurrentDesignation = '';
           $scope.Candidate.CurrentCTC = '';
           $scope.Candidate.CurrentLocation = '';
           $scope.Candidate.HomeTown = '';
           $scope.Candidate.Source = '';
           $scope.Candidate.Status = '';
           $scope.Candidate.SkillSet = '';
           $scope.Candidate.Experience = '';
           $scope.Candidate.Qualification = '';
           $scope.Candidate.NoticePeriod = '';

           $scope.Candidates = [];

           $scope.IsExpanded = false;
           $scope.IsInfoExpanded = true;
           $scope.IsStatusExpanded = false;

           $scope.IsRoleExpanded = false;
           $scope.IsCompanyExpanded = false;
           $scope.IsCreatedByExpanded = false;
           $scope.IsExperienceExpanded == false;
           $scope.IsLocationExpanded = false;
           $scope.IsSalaryExpanded = false;
           $scope.Keyword = "";

           $scope.SearchItems = {};




           $scope.LoadSearchItems = function () {
               debugger;
               CandidateService.GetSearchableItems(null).success(function (data) {
                   $scope.SearchItems = data;
                   debugger;
               }).error(function (data) {

               });
           }





           $scope.ToggleStatus = function () {
               $scope.IsStatusExpanded = !$scope.IsStatusExpanded;
           };
           $scope.ToggleRole = function () {
               $scope.IsRoleExpanded = !$scope.IsRoleExpanded;
           };
           $scope.ToggleCompany = function () {
               $scope.IsCompanyExpanded = !$scope.IsCompanyExpanded;
           };
           $scope.ToggleCreatedBy = function () {
               $scope.IsCreatedByExpanded = !$scope.IsCreatedByExpanded;
           };
           $scope.ToggleExperience = function () {
               $scope.IsExperienceExpanded = !$scope.IsExperienceExpanded;
           };

           $scope.ToggleLocation = function () {
               $scope.IsLocationExpanded = !$scope.IsLocationExpanded;
           };

           $scope.ToggleSalary = function () {
               $scope.IsSalaryExpanded = !$scope.IsSalaryExpanded;
           };


           $scope.ShowMoreStatus = function () {
               var modalInstance = $modal.open({
                   size: '1000px',
                   animation: false,
                   backdrop: 'static',
                   templateUrl: '/Templates/Candidate/More.html',
                   controller: 'moreModalCtrl',
                   scope: $scope,
                   windowClass: 'large-Modal',
                   resolve: {
                       candidate: function () {
                           return $scope.candidate;
                       }
                   }
               });
               modalInstance.result.then(function (response) {
                   debugger;
                   $scope.currentCandidate = response;
               }, function () {
                   $log.info('Modal dismissed at: ' + new Date());
               });
           };


           $scope.ShowMoreRoles = function () {
               var modalInstance = $modal.open({
                   size: '1000px',
                   animation: false,
                   backdrop: 'static',
                   templateUrl: '/Templates/Candidate/MoreRoles.html',
                   controller: 'moreModalCtrl',
                   scope: $scope,
                   windowClass: 'large-Modal',
                   resolve: {
                       candidate: function () {
                           return $scope.candidate;
                       }
                   }
               });
               modalInstance.result.then(function (response) {
                   debugger;
                   $scope.currentCandidate = response;
               }, function () {
                   $log.info('Modal dismissed at: ' + new Date());
               });
           };

           $scope.ShowMoreCreatedBy = function () {
               var modalInstance = $modal.open({
                   size: '1000px',
                   animation: false,
                   backdrop: 'static',
                   templateUrl: '/Templates/Candidate/MoreCreatedBy.html',
                   controller: 'moreModalCtrl',
                   scope: $scope,
                   windowClass: 'large-Modal',
                   resolve: {
                       candidate: function () {
                           return $scope.candidate;
                       }
                   }
               });
               modalInstance.result.then(function (response) {
                   debugger;
                   $scope.currentCandidate = response;
               }, function () {
                   $log.info('Modal dismissed at: ' + new Date());
               });
           };


           $scope.ShowMoreExperience = function () {
               var modalInstance = $modal.open({
                   size: '1000px',
                   animation: false,
                   backdrop: 'static',
                   templateUrl: '/Templates/Candidate/MoreExperience.html',
                   controller: 'moreModalCtrl',
                   scope: $scope,
                   windowClass: 'large-Modal',
                   resolve: {
                       candidate: function () {
                           return $scope.candidate;
                       }
                   }
               });
               modalInstance.result.then(function (response) {
                   debugger;
                   $scope.currentCandidate = response;
               }, function () {
                   $log.info('Modal dismissed at: ' + new Date());
               });
           };

           $scope.ShowMoreCompany = function () {
               var modalInstance = $modal.open({
                   size: '1000px',
                   animation: false,
                   backdrop: 'static',
                   templateUrl: '/Templates/Candidate/MoreCompany.html',
                   controller: 'moreModalCtrl',
                   scope: $scope,
                   windowClass: 'large-Modal',
                   resolve: {
                       candidate: function () {
                           return $scope.candidate;
                       }
                   }
               });
               modalInstance.result.then(function (response) {
                   debugger;
                   $scope.currentCandidate = response;
               }, function () {
                   $log.info('Modal dismissed at: ' + new Date());
               });
           };

           $scope.ShowMoreLocation = function () {
               var modalInstance = $modal.open({
                   size: '1000px',
                   animation: false,
                   backdrop: 'static',
                   templateUrl: '/Templates/Candidate/MoreLocation.html',
                   controller: 'moreModalCtrl',
                   scope: $scope,
                   windowClass: 'large-Modal',
                   resolve: {
                       candidate: function () {
                           return $scope.candidate;
                       }
                   }
               });
               modalInstance.result.then(function (response) {
                   debugger;
                   $scope.currentCandidate = response;
               }, function () {
                   $log.info('Modal dismissed at: ' + new Date());
               });
           };

           $scope.ShowMoreSalary = function () {
               var modalInstance = $modal.open({
                   size: '1000px',
                   animation: false,
                   backdrop: 'static',
                   templateUrl: '/Templates/Candidate/MoreSalary.html',
                   controller: 'moreModalCtrl',
                   scope: $scope,
                   windowClass: 'large-Modal',
                   resolve: {
                       candidate: function () {
                           return $scope.candidate;
                       }
                   }
               });
               modalInstance.result.then(function (response) {
                   debugger;
                   $scope.currentCandidate = response;
               }, function () {
                   $log.info('Modal dismissed at: ' + new Date());
               });
           };



           for (var i = 0; i < 10; i++) {
               var item = {
                   CandidateId: i,
                   FirstName: "FirstName" + i,
                   LastName: "LastName" + i,
                   MobileNumber: "000000000" + i,
                   Status: "Interview Scheduled",

               };
               $scope.Candidates.push(item);

           }

           $scope.recordsFound = false;



           $scope.SearchCandidate = function () {
               debugger;
               $scope.IsLoading = true;
               var selectedStatuses = GetSelectedStatus();
               var selectedRoles = GetSelectedRoles();
               var selectedCompanies = GetSelectedCompanies();
               var selectedExperience = GetSelectedExperiences();
               var selectedCreatedBy = GetSelectedCreatedBy();
               var selectedSalary = GetSelectedSalary();
               var selectedLocations = GetSelectedLocations();

               var searchInputViewModel =
                   {
                       Keyword: $scope.Keyword,
                       Status: selectedStatuses,
                       Role: selectedRoles,
                       Company: selectedCompanies,
                       Experience: selectedExperience,
                       CreatedBy: selectedCreatedBy,
                       Salary: selectedSalary,
                       Location: selectedLocations

                   };

               CandidateService.SearchCandidate(searchInputViewModel).success(function (data) {
                   debugger;
                   $scope.Candidates = [];
                   for (var i = 0; i < data.length; i++) {
                       var candidate = {
                           CandidateId: data[i].CandidateId,
                           FirstName: data[i].FirstName,
                           MiddleName: data[i].MiddleName,
                           LastName: data[i].LastName,
                           MobileNumber: data[i].MobileNumber,
                           AlternateNumber: data[i].AlternateNumber,
                           Email: data[i].Email,
                           SecondaryEmail: data[i].SecondaryEmail,
                           DateOfBirth: data[i].DateOfBirth,
                           CurrentEmployer: data[i].CurrentEmployer,
                           CurrentDesignation: data[i].CurrentDesignation,
                           CurrentCTC: data[i].CurrentDesignation,
                           CurrentLocation: data[i].CurrentLocation,
                           HomeTown: data[i].HomeTown,
                           Source: data[i].Source,
                           CandidateStatus: data[i].CandidateStatus
                       };
                       $scope.Candidates.push(candidate);
                   }

                   $scope.IsLoading = false;
               }).error(function (data) {
                   $scope.IsLoading = false;
               });

           };




           $scope.open = function (size) {

               $scope.SalaryInLacs = [];
               $scope.SalaryInThousands = [];

               var defaultLac = {
                   DisplayText: "Select Lacs",
                   Value: -1
               };

               var defaultThousand = {
                   DisplayText: "Select Thousand",
                   Value: -1
               };

               $scope.SalaryInLacs.push(defaultLac);
               $scope.SalaryInThousands.push(defaultThousand);

               for (var i = 0; i <= 50; i++) {
                   var salary = {
                       DisplayText: i,
                       Value: i
                   };

                   $scope.SalaryInLacs.push(salary);
               }

               for (var i = 0; i <= 95;) {
                   var salary = {
                       DisplayText: i,
                       Value: i
                   };

                   $scope.SalaryInThousands.push(salary);
                   i = i + 5;
               }


               var modalInstance = $modal.open({
                   size: '1000px',
                   animation: false,
                   backdrop: 'static',
                   templateUrl: '/Templates/Candidate/Create.html',
                   controller: 'createModalCtrl',
                   scope: $scope,
                   windowClass: 'large-Modal',
                   resolve: {
                       candidate: function () {
                           return $scope.candidate;
                       }
                   }
               });
               modalInstance.result.then(function (response) {
                   debugger;
                   $scope.currentCandidate = response;
               }, function () {
                   $log.info('Modal dismissed at: ' + new Date());
               });
           };


           $scope.view = function (candidate, size) {

               $scope.SelectedCandidate = candidate;
               $scope.Candidate.Profiles = [];

               debugger;
               var modalInstance = $modal.open({
                   //  size: size,
                   animation: false,
                   backdrop: 'static',
                   templateUrl: '/Templates/Candidate/View.html',
                   controller: 'viewModalCtrl',
                   scope: $scope,
                   windowClass: 'large-Modal',
                   resolve: {
                       candidate: function () {
                           return $scope.candidate;
                       }
                   }
               });
               modalInstance.result.then(function (response) {
                   debugger;
                   $scope.currentCandidate = response;
               }, function () {
                   $log.info('Modal dismissed at: ' + new Date());
               });
           };

           $scope.Edit = function (candidate, size) {

               $scope.SelectedCandidate = {};
               $scope.SelectedCandidate = candidate;
               debugger;
               var modalInstance = $modal.open({
                   //  size: size,
                   animation: false,
                   backdrop: 'static',
                   templateUrl: '/Templates/Candidate/Edit.html',
                   controller: 'editModalCtrl',
                   scope: $scope,
                   windowClass: 'large-Modal',
                   resolve: {
                       candidate: function () {
                           return $scope.candidate;
                       }
                   }
               });
               modalInstance.result.then(function (response) {
                   debugger;
                   $scope.currentCandidate = response;
               }, function () {
                   $log.info('Modal dismissed at: ' + new Date());
               });
           };

           $scope.OpenProfile = function (size) {
               //Need to add code for Profile create
               debugger;
               var modalInstance = $modal.open({
                   size: '800px',
                   //size: size,
                   animation: false,
                   backdrop: 'static',
                   templateUrl: '/Templates/Profile/Create.html',
                   controller: 'ProfileController',
                   keyboard: false,
                   scope: $scope,
                   windowClass: 'large-Modal',
                   resolve: {
                       param1: null
                   }
               });
               modalInstance.result.then(function (response) {


               }, function () {
                   $log.info('Modal dismissed at: ' + new Date());
               });
           };

           $scope.ViewProfile = function (ProfileId) {
               debugger;

               $scope.ProfileId = ProfileId;

               debugger;
               var modalInstance = $modal.open({
                   size: '800px',
                   //size: size,
                   animation: false,
                   backdrop: 'static',
                   templateUrl: '/Templates/Profile/ViewProfile.html',
                   controller: 'ProfileController',
                   keyboard: false,
                   scope: $scope,
                   windowClass: 'large-Modal',
                   resolve: {
                       param1: null
                   }
               });
               modalInstance.result.then(function (response) {


               }, function () {
                   $log.info('Modal dismissed at: ' + new Date());
               });

               //$scope.Profile = Profile.GetProfileById(ProfileId);
           }

           //$scope.ProfileView = function (ProfileId, CandidateId) {

           //};

           $scope.EditProfile = function (ProfileId, CandidateId) {

               debugger;
               var modalInstance = $modal.open({
                   size: '800px',
                   //size: size,
                   animation: false,
                   backdrop: 'static',
                   templateUrl: '/Templates/Profile/Edit.html',
                   controller: 'ProfileController',
                   keyboard: false,
                   scope: $scope,
                   windowClass: 'large-Modal',
                   resolve: {
                       param1: null
                   }
               });
               modalInstance.result.then(function (response) {


               }, function () {
                   $log.info('Modal dismissed at: ' + new Date());
               });

           };



           function GetSelectedStatus() {

               var selectedItems = [];
               for (var i = 0; i < $scope.SearchItems.Statuses.length; i++) {
                   if ($scope.SearchItems.Statuses[i].IsSelected) {
                       selectedItems.push($scope.SearchItems.Statuses[i].Code);
                   }

               }
               return selectedItems;
           };

           function GetSelectedRoles() {

               var roles = [];
               for (var i = 0; i < $scope.SearchItems.Roles.length; i++) {
                   if ($scope.SearchItems.Roles[i].IsSelected) {
                       roles.push($scope.SearchItems.Roles[i].Code);
                   }

               }
               return roles;
           };

           function GetSelectedLocations() {

               var locations = [];
               for (var i = 0; i < $scope.SearchItems.Locations.length; i++) {
                   if ($scope.SearchItems.Locations[i].IsSelected) {
                       locations.push($scope.SearchItems.Locations[i].Code);
                   }

               }
               return locations;
           };

           function GetSelectedSalary() {

               var list = [];
               for (var i = 0; i < $scope.SearchItems.Salaries.length; i++) {
                   if ($scope.SearchItems.Salaries[i].IsSelected) {
                       list.push($scope.SearchItems.Salaries[i].Code);
                   }

               }
               return list;
           };

           function GetSelectedCompanies() {

               var list = [];
               for (var i = 0; i < $scope.SearchItems.Companies.length ; i++) {
                   if ($scope.SearchItems.Companies[i].IsSelected) {
                       list.push($scope.SearchItems.Companies[i].Code);
                   }

               }
               return list;
           };


           function GetSelectedExperiences() {

               var list = [];
               for (var i = 0; i < $scope.SearchItems.Experiences.length ; i++) {
                   if ($scope.SearchItems.Experiences[i].IsSelected) {
                       list.push($scope.SearchItems.Experiences[i].Code);
                   }

               }
               return list;
           };

           function GetSelectedCreatedBy() {

               var list = [];
               for (var i = 0; i < $scope.SearchItems.CreatedBy.length ; i++) {
                   if ($scope.SearchItems.CreatedBy[i].IsSelected) {
                       list.push($scope.SearchItems.CreatedBy[i].Code);
                   }

               }
               return list;
           };



           $scope.showItems = function (item) {
               return item.Show || item.IsSelected;
           };
       }]);


    angular.module('sbAdminApp').controller('createModalCtrl',
       ['$scope', '$modalInstance', 'CandidateService', '$modal', function ($scope, $modalInstance, CandidateService, $modal) {

           
           $scope.Create = function () {
               debugger;
               var model = $scope.Candidate;

               CandidateService.comments(model).success(function (data) {
                   $scope.Message = "Candidate Created Successfully";
                   $scope.showAlert('sm');
               }).error(function (data) {
                   $scope.Message = "Candidate Created Failed";
                   $scope.showAlert('sm');
               });;


                         

           };


           $scope.showAlert = function (size) {
               debugger;
               var modalInstance = $modal.open({
                   //size: '1000px',
                   size: size,
                   animation: false,
                   backdrop: 'static',
                   templateUrl: '/Templates/Common/AlertPopUp.html',
                   controller: 'AlterModalController',
                   keyboard: false,
                   scope: $scope,
                   //windowClass: 'large-Modal',
                   resolve: {
                       param1: null
                   }
               });
               modalInstance.result.then(function (response) {


               }, function () {
                   $log.info('Modal dismissed at: ' + new Date());
               });
           };


           $scope.ok = function () {
               $modalInstance.close();
           };

           $scope.cancel = function () {
               $modalInstance.dismiss('cancel');
           };
       }]);



    angular.module('sbAdminApp').controller('viewModalCtrl',
      ['$scope', '$modalInstance', 'CandidateService', '$timeout', function ($scope, $modalInstance, CandidateService, $timeout) {

          $scope.ToggleProfile = function () {

              debugger;
              $scope.SelectedCandidate.Profiles = [];
              $scope.IsExpanded = !$scope.IsExpanded;
              if ($scope.IsExpanded) {
                  $scope.IsLoading = false;
                  var model = {
                      id: 2
                  };
                  var id = $scope.SelectedCandidate.CandidateId;
                  CandidateService.GetCandidateProfiles(null).success(function (data) {
                      $scope.SelectedCandidate.Profiles = data;
                      $scope.IsLoading = false;
                  }).error(function (data) {
                      $scope.IsLoading = false;
                  });
              }


          };


          $scope.ToggleCandidateInfo = function () {
              $scope.IsInfoExpanded = !$scope.IsInfoExpanded;

          };

          $scope.ok = function () {
              $modalInstance.close();
          };

          $scope.close = function () {
              $modalInstance.dismiss('cancel');
          };
      }]);

    angular.module('sbAdminApp').controller('editModalCtrl',
      ['$scope', '$modalInstance', 'CandidateService', function ($scope, $modalInstance, CandidateService) {


          $scope.ok = function () {
              $modalInstance.close();
          };

          $scope.cancel = function () {
              $modalInstance.dismiss('cancel');
          };


          $scope.Update = function () {
              debugger;
              var model = $scope.Candidate;
              CandidateService.UpdateCandidate(model).success(function (data) {
                  $scope.Message = "Candidate Updated Successfully";
                  $scope.showAlert('sm');
              }).error(function (data) {
                  $scope.Message = "Candidate Update Failed";
                  $scope.showAlert('sm');
              });;

          };
      }]);

    angular.module('sbAdminApp').controller('moreModalCtrl',
     ['$scope', '$modalInstance', 'CandidateService', function ($scope, $modalInstance, CandidateService) {


         $scope.close = function () {
             $modalInstance.close();
         };

         $scope.cancel = function () {
             $modalInstance.dismiss('cancel');
         };
     }]);


    angular.module('sbAdminApp').controller('AlterModalController',
    ['$scope', '$modalInstance', '$modalStack', 'param1', function ($scope, $modalInstance, $modalStack, param1) {


        $scope.closeAll = function () {
            $modalStack.dismissAll('cancel');
        };

        $scope.cancel = function () {
            $modalInstance.dismiss('cancel');
        };
        $scope.ok = function () {
            $modalInstance.close();
        };
    }]);




}(angular));
