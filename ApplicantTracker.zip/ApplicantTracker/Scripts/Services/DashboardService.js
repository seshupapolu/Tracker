﻿(function (angular) {

    angular.module('sbAdminApp').service('DashboardService',
        ['$http', '$q', '$location', 'baseApiService', function ($http, $q, $location, baseApiService) {

            function GetDashboardCount(data) {
                debugger;
                return baseApiService.sendGetQuery("GetDashboardCount", data);
            }

            return {
                GetDashboardCount: GetDashboardCount,
            };
        }]);
})
(angular);