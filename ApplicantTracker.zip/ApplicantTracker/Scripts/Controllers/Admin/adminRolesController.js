﻿(function (angular) {
    angular.module('sbAdminApp').controller('adminRolesController',
        ['$scope', '$modal', 'userService', function ($scope, $modal, userService) {
            debugger;

            userService.getAllRoles()
                       .success(function (data) {
                           debugger;
                           //alert(data);
                           $scope.items = data;
                           // $scope.isLoading = false;                            

                       })
                       .error(function (data) {
                           debugger;
                           //$scope.isLoading = false;
                           console.log('Error: ', data)
                       });

            $scope.createEdit = function (id, flag) {

                userService.getAllRoles()
                   .success(function (data) {

                       debugger;
                       $scope.items = data;
                       $scope.statusEdit = {};
                       $scope.statusEdit.RoleId= id + 1;;

                       angular.forEach($scope.items, function (value, key) {
                           debugger;

                           if (value.RoleId == $scope.statusEdit.RoleId) {

                               $scope.statusEdit.Name = value.Name;
                               $scope.statusEdit.Description = value.Description;
                               $scope.statusEdit.IsActive = value.IsActive;
                           }

                       });

                       debugger;
                       var modalInstance = $modal.open({
                           size: '500px',
                           animation: false,
                           backdrop: 'static',
                           templateUrl: '/Templates/Admin/admin-edit-list.html',
                           controller: 'adminRoleEditCtrl',
                           scope: $scope,
                           windowClass: 'large-Modal',
                           resolve: {
                               adminEdit: function () {
                                   return $scope.adminEdit;
                               }
                           }
                       });
                       modalInstance.result.then(function (response) {
                           debugger;
                       }, function () {
                           $log.info('Modal dismissed at: ' + new Date());
                       });


                   })
                   .error(function (data) {
                       debugger;
                       //$scope.isLoading = false;
                       console.log('Error: ', data)
                   });


            };

            $scope.deleteItem = function (role, flag) {
                debugger;

                if (!flag) {

                    user.IsActive = false;
                    userService.disableCompany(role);
                }

                $modalInstance.dismiss('cancel');
            };

            //$scope.items = [
            //    {
            //        Id: 0,
            //        Title: 'Associate',                    
            //        Details: 'description',
            //        Isactive:'True'

            //    }, {
            //        Title: 'Team Leader',
            //        Id: 1,
            //        Details: 'description',
            //        Isactive: 'True'
            //    }, {
            //        Title: 'Manager',
            //        Id: 2,
            //        Details: 'description',
            //        Isactive: 'True'
            //    }
            //];
        }]);


    angular.module('sbAdminApp').controller('adminRoleEditCtrl',
['$scope', '$modalInstance', 'userService', function ($scope, $modalInstance, userService) {

    $scope.Update = function () {
        debugger;
        var model = $scope.statusEdit;
        userService.UpdateRole(model);

        userService.getAllStatus()
                     .success(function (data) {
                         debugger;
                         //alert(data);
                         $scope.items = data;
                         // $scope.isLoading = false;                            

                     })
                     .error(function (data) {
                         debugger;
                         //$scope.isLoading = false;
                         console.log('Error: ', data)
                     });


        $modalInstance.dismiss('cancel');
    };

    $scope.ok = function () {
        $modalInstance.close();
    };

    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
}]);

})
(angular);