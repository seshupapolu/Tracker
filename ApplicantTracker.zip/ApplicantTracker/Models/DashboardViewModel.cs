﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ApplicantTracker.Models
{
    public class DashboardViewModel
    {
        public int NewProfiles { get; set; }
        public int NewInterviews { get; set; }
        public int ActiveProfiles { get; set; }
        public int OfferReleases { get; set; }
        public int TotalEmployees { get; set; }
    }
}