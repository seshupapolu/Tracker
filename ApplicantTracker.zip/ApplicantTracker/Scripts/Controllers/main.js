
/**
 * @ngdoc function
 * @name sbAdminApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the sbAdminApp
 */
(function (angular) {'use strict';
angular.module('sbAdminApp')
  .controller('MainCtrl', function($scope,$position) {
  });
  })
(angular);
