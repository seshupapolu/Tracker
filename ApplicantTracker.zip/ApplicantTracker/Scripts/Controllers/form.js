
/**
 * @ngdoc function
 * @name sbAdminApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the sbAdminApp
 */
(function (angular) {'use strict';
angular.module('sbAdminApp')
  .controller('FormCtrl', function($scope) {
    
  });
})
(angular);